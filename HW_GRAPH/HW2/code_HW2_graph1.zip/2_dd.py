import networkx as nx
import collections
import matplotlib.pyplot as plt
import numpy as np
import math
import operator as op

from functools import reduce

n = 1000
p = 0.5

x = []
y = []

# dd = 1 / math.sqrt(n-1)

# dd = math.sqrt(((1-p) / p) * (1 / (n-1)))
# print("dd : " ,dd)


def nCr(n, r) :
    r = min(r, n-r)
    numerator = reduce(op.mul, range(n, n-r, -1), 1)
    denominator = reduce(op.mul, range(1, r+1), 1)
    return numerator // denominator

print(nCr(3,2))

# k = 0
# dd2 = nCr(n-1, k) * math.pow(p, k) * math.pow(1-p, n-1-k)
# print("dd2 : ", dd2)

k = np.arange(0, n, 1)
print("k : ", k)
d = []

for i in range(len(k)) :
    dd2 = nCr(n-1, k[i]) * math.pow(p, k[i]) * math.pow(1-p, n-1-k[i])
    # print(i, ' : ', round(dd2, 2))
    d.append(dd2)

plt.plot(k, d, '*-', linewidth=1, color='r')
plt.xlabel('k')
plt.ylabel('P(k)')
plt.xticks(np.arange(0, 1001, 100))
# plt.show()

G = nx.erdos_renyi_graph(n, p)

degree_sequence = sorted([d for n, d in G.degree()], reverse=True)  # degree sequence


degreeCount = collections.Counter(degree_sequence)
# print("count : ", degreeCount)
deg, cnt = zip(*degreeCount.items())

print("cnt : ", cnt, type(cnt))
print("cntss : " ,cnt[0])
print("sum : ", sum(cnt))
print("len : ", len(cnt))

aa = cnt[0] + cnt[1]
print("aaa : " , aa)

temp_sum = 0

for i in range(len(cnt)) :
    temp_sum = temp_sum + cnt[i]
z = []
for i in range(len(cnt)) :
    z.append(round(cnt[i] / temp_sum, 2))

print("z : ", z)
# plt.bar(deg, cnt, width=0.80, color="b")
plt.bar(deg, z, width=0.80, color="b")
plt.show()