import networkx as nx
import collections
import matplotlib.pyplot as plt
import numpy as np

n = 10
p = 0

x = []
y = []

# try :
#     G = nx.erdos_renyi_graph(n, p)
#     diameter = nx.diameter(G)

#     print("diameter : ", diameter)
# except :
#     print("INFINITE")
#     pass


for i in range(10) :
    p = p + 0.1
    G = nx.erdos_renyi_graph(n, p)

    x.append(p)

    try :
        diameter = nx.diameter(G)
        print(p, "dia : ", diameter)
        y.append(diameter)

    except :
        print("INFINITE")
        y.append(0)



plt.plot(x, y, '*-', linewidth=1, color='y')
plt.xlabel('p')
plt.ylabel('diameter')
plt.xticks(np.arange(0, 1.1, 0.1))
plt.show()


# G = nx.erdos_renyi_graph(n, p)

# path = dict(nx.shortest_path_length(G))
# # print(nx.shortest_path_length.(G, source=0))

# for i in range(n) :
#     # print("i : ", i)
#     for j in range(n) :
#         # print("j : ", j)
#         print(i, "->", j, path[i][j])
# # print(path[0][4])

# # print("max : ", max(path))
# print("path : ", path)

# print("max2 : ", nx.diameter(G))