import networkx as nx
import collections
import matplotlib.pyplot as plt
import numpy as np

n = 10
p = 0

x = []
y = []

# print(nx.connected_components(G))
print("clustering coefficient")

for i in range(10) :
    p = p + 0.1
    G = nx.erdos_renyi_graph(n, p)

    cls_coef = nx.average_clustering(G)
    x.append(p)
    y.append(cls_coef)

plt.plot(x, y, '*-', linewidth=1, color='y')

# plt.xticks(np.arange(0, 1001, 100))
# plt.show()

x = []
y = []
p = 0

for i in range(100) :
    p = p + 0.01
    G = nx.erdos_renyi_graph(n, p)

    cls_coef = nx.average_clustering(G)
    x.append(p)
    y.append(cls_coef)

plt.plot(x, y, '*-', linewidth=1, color='b')

x = []
y = []
p = 0


#### 이론값 -> C = p(빨간색)
for i in range(100) :
    p = p + 0.01
    C = p

    x.append(p)
    y.append(C)

plt.plot(x, y, '.', linewidth=0.2, color='r')



# x = []
# y = []
# p = 0

# for i in range(1000) :
#     p = p + 0.001
#     G = nx.erdos_renyi_graph(n, p)

#     cls_coef = nx.average_clustering(G)
#     x.append(p)
#     y.append(cls_coef)

# plt.plot(x, y, '*-', linewidth=1, color='g')

plt.xlabel('p')
plt.ylabel('clustering coefficient')
plt.show()

# #### p가 0.01 단위로 커질때
# for i in range(100) :
#     p = p + 0.01
#     G = nx.erdos_renyi_graph(n, p)

#     cc = sorted(nx.connected_components(G), key=len, reverse=True)

#     print("p : ", round(p, 2), "/ Count : ", len(cc))
#     print("cc : ", cc)

#     x.append(p)
#     y.append(len(cc))


# plt.plot(x, y, '*-', linewidth=1, color='r')
# plt.xlabel('probablity')
# plt.ylabel('# of Connected Component')
# plt.xticks(np.arange(0, 1.1, 0.1))
# plt.show()
