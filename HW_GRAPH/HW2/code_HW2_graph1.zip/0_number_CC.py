import networkx as nx
import collections
import matplotlib.pyplot as plt
import numpy as np

n = 10
p = 0

x = []
y = []

# print(nx.connected_components(G))


#### p가 0.1 단위로 커질때
for i in range(10) :
    p = p + 0.1
    G = nx.erdos_renyi_graph(n, p)

    cc = sorted(nx.connected_components(G), key=len, reverse=True)
    # largest = max(nx.connected_components(G), key=len)

    print("p : ", round(p, 2), "/ Count : ", len(cc))
    print("cc : ", cc)

    x.append(p)
    y.append(len(cc))

plt.plot(x, y, '*-', linewidth=1)


x = []
y = []
p = 0

#### p가 0.01 단위로 커질때
for i in range(100) :
    p = p + 0.01
    G = nx.erdos_renyi_graph(n, p)

    cc = sorted(nx.connected_components(G), key=len, reverse=True)

    print("p : ", round(p, 2), "/ Count : ", len(cc))
    print("cc : ", cc)

    x.append(p)
    y.append(len(cc))


plt.plot(x, y, '*-', linewidth=1, color='r')
plt.xlabel('probablity')
plt.ylabel('# of Connected Component')
plt.xticks(np.arange(0, 1.1, 0.1))
plt.show()

# print("node degree clustering")
# for v in nx.nodes(G):
#     print(f"{v} {nx.degree(G, v)} {nx.clustering(G, v)}")

    
# print("diameter : ", nx.diameter(G))